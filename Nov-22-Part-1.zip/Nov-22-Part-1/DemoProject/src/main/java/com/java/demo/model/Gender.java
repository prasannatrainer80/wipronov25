package com.java.demo.model;

public enum Gender {
	MALE, FEMALE
}
