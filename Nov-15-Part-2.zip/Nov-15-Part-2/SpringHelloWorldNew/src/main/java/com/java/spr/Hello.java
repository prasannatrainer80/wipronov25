package com.java.spr;

public interface Hello {
	String show(String name);
}
