package com.java.wipro;

public class Greeting {

	private String message = "Good Morning...";

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
