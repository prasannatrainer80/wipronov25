package com.java.wipro.model;

public enum Gender {
	MALE, FEMALE
}
