package com.java.wipro;

import org.junit.Test;

public class AppTest {

  @Test
  public void testMain() {
    App.main(null);
  }

}
