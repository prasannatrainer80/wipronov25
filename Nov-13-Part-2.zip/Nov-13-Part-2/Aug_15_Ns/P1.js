console.log("Welcome to Node Js...");
console.error("Error Message...");
console.warn("Warning Message...");