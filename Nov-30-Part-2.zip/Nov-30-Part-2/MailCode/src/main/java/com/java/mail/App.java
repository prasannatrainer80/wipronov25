package com.java.mail;

public class App {

  public static void main(String[] args) {
    System.out.println("Hello World!");
    MailSend.sendMail("iamprakashsatya707@gmail.com", "Java Program Mail", "Welcome this is First Mail By Program...");
  }

}
